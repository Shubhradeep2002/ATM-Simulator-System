package bank.management.system;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;



public class SignUpTwo extends JFrame implements ActionListener{
    //14) Need to get all data entered by user . So making local var.->Global var.
    String formno;
    JTextField aadhar,pan;
    JButton next;
    JRadioButton existyes,existno,srcitiyes,srcitino;
    JComboBox religion,categ,income,education,occupation;

    SignUpTwo(String formno)
    //Constructor
    //formno=> Primary Key to determine SignUpOne & SignUpTwo of same person
    //To carry forward formno. from SignUpOne to SignUpTwo
    {
        this.formno=formno;
        setLayout(null);

        setTitle("NEW ACCOUNT APPLICATION AND FORM - PAGE 2");
        getContentPane().setBackground(Color.WHITE);

        JLabel additionalDetails=new JLabel("Page 2- Additional Details");
        additionalDetails.setFont(new Font("Raleway",Font.BOLD,22));
        additionalDetails.setBounds(290,80,400,30);
        add(additionalDetails);

        JLabel relname=new JLabel("Religion:");
        relname.setFont(new Font("Raleway",Font.BOLD,20));
        relname.setBounds(100,140,100,30);
        add(relname);

        String valReli[]={"Hindu","Muslim","Christian","Sikh","Other"};
        religion = new JComboBox(valReli);
        religion.setBackground(Color.WHITE);
        religion.setBounds(300,140,400,30);//8) Since want it just beside name , hence y coordinate same
        add(religion);

        JLabel cname=new JLabel("Category");
        cname.setFont(new Font("Raleway",Font.BOLD,20));
        cname.setBounds(100,190,200,30);
        add(cname);

        String valCateg[]={"General","OBC","SC","ST","Other"};
        categ = new JComboBox(valCateg);//For Drop Down Options
        categ.setBackground(Color.WHITE);
        categ.setBounds(300,190,400,30);
        add(categ);

        JLabel inc=new JLabel("Income:");//10) Ability to choose date instead of Text Field-> jcalendar jar file reqd. to import
        inc.setFont(new Font("Raleway",Font.BOLD,20));
        inc.setBounds(100,240,200,30);
        add(inc);

        String valInc[]={"Null","Less than 100000","100000-200000","200000-500000","Above 500000"};
        income = new JComboBox(valInc);
        income.setBackground(Color.WHITE);
        income.setBounds(300,240,400,30);
        add(income);

        JLabel edu=new JLabel("Educational");
        edu.setFont(new Font("Raleway",Font.BOLD,20));
        edu.setBounds(100,290,200,30);//5) [270+30=320] + 20 = 290
        add(edu);

        JLabel quali=new JLabel("Qualification:");
        quali.setFont(new Font("Raleway",Font.BOLD,20));
        quali.setBounds(100,315,200,30);//6) [290+30=320] + 20 = 340
        add(quali);

        String valEdu[]={"Graduate","Post Graduate","Non-Graduate","Doctorate","Other"};
        education = new JComboBox(valEdu);//For Drop Down Options
        education.setBackground(Color.WHITE);
        education.setBounds(300,315,400,30);
        add(education);

        JLabel occu=new JLabel("Occupation:");//9) The Yes/No check boxes for marital/Gender are called radio buttons
        occu.setFont(new Font("Raleway",Font.BOLD,20));
        occu.setBounds(100,390,200,30);//7) [340+30=320] + 20 = 390
        add(occu);

        String valOccu[]={"Intern","Salaried","Self-Employed","Free-Lancing","Other"};
        occupation = new JComboBox(valOccu);//For Drop Down Options
        occupation.setBackground(Color.WHITE);
        occupation.setBounds(300,390,400,30);
        add(occupation);

        JLabel panno=new JLabel("Pan No.:");
        panno.setFont(new Font("Raleway",Font.BOLD,20));
        panno.setBounds(100,440,200,30);
        add(panno);

        //JTextField addressTextField=new JTextField();
        pan=new JTextField();
        pan.setFont(new Font("Raleway",Font.BOLD,20));
        pan.setBounds(300,440,400,30);
        add(pan);

        JLabel aadharno=new JLabel("Aadhar No.:");
        aadharno.setFont(new Font("Raleway",Font.BOLD,20));
        aadharno.setBounds(100,490,200,30);
        add(aadharno);

        //JTextField cityTextField=new JTextField();
        aadhar=new JTextField();
        aadhar.setFont(new Font("Raleway",Font.BOLD,20));
        aadhar.setBounds(300,490,400,30);
        add(aadhar);

        JLabel sr=new JLabel("Sr. Citizen or Not:");
        sr.setFont(new Font("Raleway",Font.BOLD,20));
        sr.setBounds(100,540,200,30);
        add(sr);

        srcitiyes= new JRadioButton("Yes");
        srcitiyes.setBounds(300,540,100,20);
        srcitiyes.setBackground(Color.WHITE);
        add(srcitiyes);

        srcitino= new JRadioButton("No");
        srcitino.setBounds(450,540,100,30);
        srcitino.setBackground(Color.WHITE);
        add(srcitino);

        ButtonGroup srcitizen= new ButtonGroup();//13) This will allow to to set gender as either male/female else by mistake there was possibility both Genders could be selected
        srcitizen.add(srcitiyes);
        srcitizen.add(srcitino);

        JLabel exist=new JLabel("Existing Account:");
        exist.setFont(new Font("Raleway",Font.BOLD,20));
        exist.setBounds(100,590,200,30);
        add(exist);

        existyes= new JRadioButton("Yes");
        existyes.setBounds(300,590,100,20);
        existyes.setBackground(Color.WHITE);
        add(existyes);

        existno= new JRadioButton("No");
        existno.setBounds(450,590,100,30);
        existno.setBackground(Color.WHITE);
        add(existno);

        ButtonGroup accountexist= new ButtonGroup();//13) This will allow to to set gender as either male/female else by mistake there was possibility both Genders could be selected
        accountexist.add(existyes);
        accountexist.add(existno);

        //JButton next= new JButton("Next");
        next= new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);//21) For validation
        add(next);

        setSize(850,800);
        setLocation(350,10);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae){
        String sreligion=(String) religion.getSelectedItem();//Extract as String from Drop Down
        String scateg=(String) categ.getSelectedItem();
        String sincome= (String) income.getSelectedItem();
        String seduc=(String) education.getSelectedItem();
        String soccupation=(String) occupation.getSelectedItem();
        String sr=null;
        if(srcitiyes.isSelected()){
            sr="Yes";
        }
        else if(srcitino.isSelected()) {
            sr = "No";
        }

        String exist=null;
        if(existyes.isSelected()){
            exist="Yes";
        }
        else if(existno.isSelected()){
            exist="No";
        }

        String span=pan.getText();
        String saadhar=aadhar.getText();

        try{//19) Exception handling reqd. as DB external entity and there can be run time/compile time error
                Conn c = new Conn();//22) Connection making with DB
                String query = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scateg+"','"+sincome+"','"+seduc+"','"+soccupation+"','"+span+"','"+saadhar+"','"+sr+"','"+exist +"')";
                //21)Syntax for variable concat with string/treat as String- "String'"+var. name+"'String"
                c.s.executeUpdate(query);

                setVisible(false);
                new SignUpThree(formno).setVisible(true);
            }

        catch (Exception e){
            System.out.println(e);
        }
    }


    public static void main(String args[])
    {
        new SignUpTwo("");
    }
}
