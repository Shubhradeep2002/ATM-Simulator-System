package bank.management.system;
//1)JDBC Connectivity-> Java Database
/*2)Steps in JDBC:
-Register the driver
-Create Connection
-Create Statement
-Execute Query
-Close Connection
 */
//3)No main method here as this class will be used as object

import java.sql.*;


public class Conn {
    Connection c;//7)Global Object
    Statement s;
    public Conn()//4)=>Constructor
    {
        try{//5)To eliminate run time and compile time errors while running external app=> MySQL
            //10)Class.forName(com.mysql.cj.jdbc.Driver);//6)Class name is Class,Registering Driver with Driver name in ().This needs a library to be imported to function
            //jar file can automatically file
            //c=DriverManager.getConnection("jdbc:mysql://localhost:3306");//8) localhost:3306-> By default
            c=DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","p@SS#SQL02");//9) Copy paste DB name after creating from MySQL
            s=c.createStatement();
        }catch (Exception e) {
            System.out.println(e);
        }
    }

}
