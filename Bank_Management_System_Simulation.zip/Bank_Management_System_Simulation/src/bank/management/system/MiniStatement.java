package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.ResultSet;

public class MiniStatement extends JFrame implements ActionListener {
    String pinnumber;
    JButton print;
    MiniStatement(String pinnumber)
    {
        this.pinnumber=pinnumber;
        setLayout(null);
        setTitle("Mini Statement");

        JLabel mini=new JLabel();
        mini.setBounds(20,140,400,200);
        add(mini);//Dynamically text print

        print=new JButton("PRINT");
        print.setBounds(280,20,100,20);
        print.setBackground(Color.BLACK);
        print.setForeground(Color.WHITE);//text colour
        print.addActionListener(this);
        add(print);

        JLabel bank = new JLabel("Indian Bank");
        bank.setBounds(150,20,100,20);
        add (bank);

        JLabel balance=new JLabel();
        balance.setBounds(20,400,300,20);
        add(balance);

        JLabel card=new JLabel();
        card.setBounds(20,80,300,20);
        add(card);

        try{
            Conn c=new Conn();
            ResultSet rs=c.s.executeQuery("select * from login where pin='"+pinnumber+"'");
            while(rs.next()){
                card.setText("Card Number: "+rs.getString("cardnumber").substring(0,4)+"xxxxxxxx"+rs.getString("cardnumber").substring(12));//To not show full card no.
            }//To shoow card no.
        }catch (Exception e)
        {
            System.out.println(e);
        }

        try {
            Conn c=new Conn();
            int bal=0;
            ResultSet rs=c.s.executeQuery("select * from bank where pin='"+pinnumber+"'");
            while(rs.next()) {
                mini.setText(mini.getText() + "<html>" + rs.getString("date") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs.getString("amount") + "<br><br><html>");
                //Using html tag for creating space by &nbsp;
                //<br>-> Breaks rows
                //To show data corresponding card no.
                if(rs.getString("type").equals("Deposit")) {

                    bal +=Integer.parseInt(rs.getString("amount")) ;
                } else{
                    bal -=Integer.parseInt(rs.getString("amount")) ;
                }
                balance.setText("Your Current Account Balance: Rs."+bal);
            }
        }catch (Exception e)
        {
            System.out.println(e);
        }

        setSize(400,600);
        getContentPane().setBackground(Color.white);
        setLocation(20,20);
        setVisible(true);
    }

    public static void main(String args[])
    {
        new MiniStatement("").setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            // Create a PrinterJob
            PrinterJob printerJob = PrinterJob.getPrinterJob();

            // Set the MiniStatement frame as the printable component
            printerJob.setPrintable(new Printable() {
                @Override
                public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
                    if (pageIndex > 0) {
                        return Printable.NO_SUCH_PAGE;
                    }
                    // Calculate the scaling factor
                    double scaleX = pageFormat.getImageableWidth() / getContentPane().getWidth();
                    double scaleY = pageFormat.getImageableHeight() / getContentPane().getHeight();
                    double scale = Math.min(scaleX, scaleY);

                    // Create a Graphics2D object
                    Graphics2D g2d = (Graphics2D) graphics;

                    // Translate and scale to fit the entire frame within the printable area
                    g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                    g2d.scale(scale, scale);

                    // Print all components except the PRINT button
                    printComponents(g2d);

                    return Printable.PAGE_EXISTS;
                }
            });

            // Show print dialog to the user
            if (printerJob.printDialog()) {
                // Print the MiniStatement view
                printerJob.print();
            }
        } catch (PrinterException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred while printing", "Printing Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
