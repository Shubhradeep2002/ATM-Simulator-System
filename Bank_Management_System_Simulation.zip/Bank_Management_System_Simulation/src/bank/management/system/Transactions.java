package bank.management.system;

import javax.swing.*;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Transactions extends JFrame implements ActionListener {

    JButton deposit, withdrawal, fastcash, ministatement, pinchange, balanceenquiry, exit;
    String pinnumber;
    Transactions(String pinnumber) {//3) Carry forwarding pinnumber for further transactions so that user not need to enter pin every time
        this.pinnumber=pinnumber;//5) Storing Local var. in Global var

        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 900);
        add(image);

        JLabel text = new JLabel("Please select Transaction");
        text.setBounds(210, 300, 700, 35);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("Raleway", Font.BOLD, 16));
        image.add(text);
        //add(text);//1) add text to frame but not over image so not visible as image hides text)

        deposit = new JButton("Deposit");
        deposit.setBounds(170, 415, 150, 30);
        deposit.addActionListener(this);
        image.add(deposit);

        withdrawal = new JButton("Cash Withdrawal");
        withdrawal.setBounds(355, 415, 150, 30);
        withdrawal.addActionListener(this);
        image.add(withdrawal);

        fastcash = new JButton("Fast Cash");
        fastcash.setBounds(170, 450, 150, 30);
        fastcash.addActionListener(this);
        image.add(fastcash);

        ministatement = new JButton("Mini Statement");
        ministatement.setBounds(355, 450, 150, 30);
        ministatement.addActionListener(this);
        image.add(ministatement);

        pinchange = new JButton("Change PIN");
        pinchange.setBounds(170, 485, 150, 30);
        pinchange.addActionListener(this);
        image.add(pinchange);

        balanceenquiry = new JButton("Balance Enquiry");
        balanceenquiry.setBounds(355, 485, 150, 30);
        balanceenquiry.addActionListener(this);
        image.add(balanceenquiry);

        exit = new JButton("Exit");
        exit.setBounds(355, 520, 150, 30);
        exit.addActionListener(this);
        image.add(exit);

        setSize(900, 900);
        setLocation(300, 0);
        setUndecorated(true);//The top status bar gets removed
        setVisible(true);//2) setVisible() must be at end

    }


    public static void main(String args[]) {
        new Transactions("");
    }//4) ""

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exit)
            System.exit(0);
        else if (e.getSource()==deposit) {
            setVisible(false);//6) Close  current frame
            new Deposit(pinnumber).setVisible(true);//Carry forward pinnumber => while depositing will verify pinnumber
        }else if (e.getSource()==withdrawal) {
            setVisible(false);//6) Close  current frame
            new Withdrawal(pinnumber).setVisible(true);//Carry forward pinnumber => while depositing will verify pinnumber
        }else if (e.getSource()==fastcash) {
            setVisible(false);
            new FastCash(pinnumber).setVisible(true);
        }else if (e.getSource()==pinchange) {
            setVisible(false);
            new PinChange(pinnumber).setVisible(true);
        }else if (e.getSource()==balanceenquiry) {
            setVisible(false);
            new BalanceEnquiry(pinnumber).setVisible(true);
        }else if (e.getSource()==ministatement) {
            //setVisible(false);-> Want Transactions section to be open and on left mini statement appears
            new MiniStatement(pinnumber).setVisible(true);
        }
    }
}


