package bank.management.system;
import javax.swing.*;
import java.util.*;//2) For Random class
import java.awt.*;
import java.awt.event.*;//16)For ActionListener()
import com.toedter.calendar.JDateChooser;//11) For dob date


public class SignUpOne extends JFrame implements ActionListener{
        //14) Need to get all data entered by user . So making local var.->Global var.
        long random;
        JTextField nameTextField,fnameTextField,emailTextField,addressTextField,cityTextField,stateTextField,pinTextField;
        JButton next;
        JRadioButton male,female,other,married,unmarried;
        JDateChooser dateChooser;

    SignUpOne(){
            setLayout(null);

            Random ran=new Random();//3) Random no. for formno.
            random= Math.abs((ran.nextLong() % 9000L) + 1000L);//4) Math.abs for modulus val of negative no.
            JLabel formno=new JLabel("APPLICATION FORM NO.:"+random);//1) 4 digit unique Random no.

            getContentPane().setBackground(Color.WHITE);
            formno.setFont(new Font("Raleway",Font.BOLD,38));
            formno.setBounds(140,20,600,40);
            add(formno);

            JLabel personalDetails=new JLabel("Page 1- Personal Details"+random);
            personalDetails.setFont(new Font("Raleway",Font.BOLD,22));
            personalDetails.setBounds(290,80,400,30);
            add(personalDetails);

            JLabel name=new JLabel("Name:");
            name.setFont(new Font("Raleway",Font.BOLD,20));
            name.setBounds(100,140,100,30);
            add(name);

            //JTextField nameTextField=new JTextField();
            nameTextField=new JTextField();//15)Local Definitions being removed since globally declared now
            nameTextField.setFont(new Font("Raleway",Font.BOLD,20));
            nameTextField.setBounds(300,140,400,30);//8) Since want it just beside name , hence y coordinate same
            add(nameTextField);

            JLabel fname=new JLabel("Father's Name:");
            fname.setFont(new Font("Raleway",Font.BOLD,20));
            fname.setBounds(100,190,200,30);
            add(fname);

            //JTextField fnameTextField=new JTextField();
            fnameTextField=new JTextField();
            fnameTextField.setFont(new Font("Raleway",Font.BOLD,20));
            fnameTextField.setBounds(300,190,400,30);
            add(fnameTextField);

            JLabel dob=new JLabel("D.O.B:");//10) Ability to choose date instead of Text Field-> jcalendar jar file reqd. to import
            dob.setFont(new Font("Raleway",Font.BOLD,20));
            dob.setBounds(100,240,200,30);
            add(dob);

            //JDateChooser dateChooser =new JDateChooser();
            dateChooser =new JDateChooser();
            dateChooser.setBounds(300,240,400,30);
            dateChooser.setForeground(Color.red);//12) Can also create colour using RGB->newColor(105,105,105)
            add(dateChooser);

            JLabel gender=new JLabel("Gender:");
            gender.setFont(new Font("Raleway",Font.BOLD,20));
            gender.setBounds(100,290,200,30);//5) [270+30=320] + 20 = 290
            add(gender);

            //JRadioButton male= new JRadioButton("Male");
            male= new JRadioButton("Male");
            male.setBounds(300,290,60,30);
            male.setBackground(Color.WHITE);
            add(male);

            //JRadioButton female= new JRadioButton("Female");
            female= new JRadioButton("Female");
            female.setBounds(450,290,120,30);
            female.setBackground(Color.WHITE);
            add(female);

            ButtonGroup gendergroup= new ButtonGroup();//13) This will allow to to set gender as either male/female else by mistake there was possibility both Genders could be selected
            gendergroup.add(male);
            gendergroup.add(female);

            JLabel email=new JLabel("Email Address:");
            email.setFont(new Font("Raleway",Font.BOLD,20));
            email.setBounds(100,340,200,30);//6) [290+30=320] + 20 = 340
            add(email);

            //JTextField emailTextField=new JTextField();
            emailTextField=new JTextField();
            emailTextField.setFont(new Font("Raleway",Font.BOLD,20));
            emailTextField.setBounds(300,340,400,30);
            add(emailTextField);

            JLabel marital=new JLabel("Marital Status:");//9) The Yes/No check boxes for marital/Gender are called radio buttons
            marital.setFont(new Font("Raleway",Font.BOLD,20));
            marital.setBounds(100,390,200,30);//7) [340+30=320] + 20 = 390
            add(marital);

            //JRadioButton married= new JRadioButton("Married");
            married= new JRadioButton("Married");
            married.setBounds(300,390,100,30);
            married.setBackground(Color.WHITE);
            add(married);

            //JRadioButton unmarried= new JRadioButton("Unmarried");
            unmarried= new JRadioButton("Unmarried");
            unmarried.setBounds(450,390,100,30);
            unmarried.setBackground(Color.WHITE);
            add(unmarried);

            //JRadioButton other= new JRadioButton("Other");
            other= new JRadioButton("Other");
            other.setBounds(630,390,100,30);
            other.setBackground(Color.WHITE);
            add(other);

            ButtonGroup maritalgroup= new ButtonGroup();
            maritalgroup.add(married);
            maritalgroup.add(unmarried);
            maritalgroup.add(other);

            JLabel address=new JLabel("Address:");
            address.setFont(new Font("Raleway",Font.BOLD,20));
            address.setBounds(100,440,200,30);
            add(address);

            //JTextField addressTextField=new JTextField();
            addressTextField=new JTextField();
            addressTextField.setFont(new Font("Raleway",Font.BOLD,20));
            addressTextField.setBounds(300,440,400,30);
            add(addressTextField);

            JLabel city=new JLabel("City:");
            city.setFont(new Font("Raleway",Font.BOLD,20));
            city.setBounds(100,490,200,30);
            add(city);

            //JTextField cityTextField=new JTextField();
            cityTextField=new JTextField();
            cityTextField.setFont(new Font("Raleway",Font.BOLD,20));
            cityTextField.setBounds(300,490,400,30);
            add(cityTextField);

            JLabel state=new JLabel("State:");
            state.setFont(new Font("Raleway",Font.BOLD,20));
            state.setBounds(100,540,200,30);
            add(state);

            //JTextField stateTextField=new JTextField();
            stateTextField=new JTextField();
            stateTextField.setFont(new Font("Raleway",Font.BOLD,20));
            stateTextField.setBounds(300,540,400,30);
            add(stateTextField);

            JLabel pincode=new JLabel("PIN Code:");
            pincode.setFont(new Font("Raleway",Font.BOLD,20));
            pincode.setBounds(100,590,200,30);
            add(pincode);

            //JTextField pinTextField=new JTextField();
            pinTextField=new JTextField();
            pinTextField.setFont(new Font("Raleway",Font.BOLD,20));
            pinTextField.setBounds(300,590,400,30);
            add(pinTextField);

            //JButton next= new JButton("Next");
            next= new JButton("Next");
            next.setBackground(Color.BLACK);
            next.setForeground(Color.WHITE);
            next.setFont(new Font("Raleway",Font.BOLD,14));
            next.setBounds(620,660,80,30);
            next.addActionListener(this);//21) For validation
            add(next);

            setSize(850,800);
            setLocation(350,10);
            setVisible(true);

    }

    public void actionPerformed(ActionEvent ae){
            String formno = "" + random;//17) No if-else reqd. since only 1 button. Now val have to be entered in DB
            //DB will String val for formno but it is long
            //=>String conversion[CONCAT] Syntax->"" +
            String name=nameTextField.getText();//18) get val. from text field
            String fname=fnameTextField.getText();
            String dob= ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
            String gender=null;
            if(male.isSelected()){
                    gender="Male";
            }
            else{
                    gender="Female";
            }

            String email= emailTextField.getText();
            String marital=null;
            if(married.isSelected()){
                    marital="Married";
            }
            else if(unmarried.isSelected()){
                    marital="Unmarried";
            }
            else{
                    marital="Other";
            }

            String address=addressTextField.getText();
            String city=cityTextField.getText();
            String state=stateTextField.getText();
            String pin=pinTextField.getText();

            try{//19) Exception handling reqd. as DB external entity and there can be run time/compile time error
                    if(name.equals("")){
                            JOptionPane.showMessageDialog(null,"Name is Reqd.");//20) -> Validation=> If no name then this message shown
                    }else{
                            Conn c = new Conn();//22) Connection making with DB
                            String query = "insert into signup values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+marital+"','"+address+"','"+city+"','"+state +"','"+pin+"')";

                            //21)Syntax for variable concat with string/treat as String- "String'"+var. name+"'String"
                            c.s.executeUpdate(query);

                            setVisible(false);
                            new SignUpTwo("").setVisible(true);//On Next Click open SignUpTwo and close SignUpOne
                    }
            }
            catch (Exception e){
                    System.out.println(e);
            }
    }


    public static void main(String args[])
    {
        new SignUpOne();
    }
    }
