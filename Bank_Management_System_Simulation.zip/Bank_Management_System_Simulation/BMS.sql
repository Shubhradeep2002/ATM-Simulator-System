create database bankmanagementsystem;

show databases;/*How databases Automatically created?*/

use bankmanagementsystem;

create table signup(formno varchar(20),name varchar(20),father_name varchar(20),dob varchar(20),gender varchar(20),email varchar(30),marital_status varchar(20),address varchar(40),city varchar(25),pincode varchar(20),state varchar(25));
show tables;

/*DROP TABLE signup;*/
select * from signup;
select * from signuptwo;

create table signuptwo(formno varchar(20),sreligion varchar(20),scateg varchar(20),sincome varchar(20),seduc varchar(20),soccupation varchar(20),span varchar(20),saadhar varchar(20),sr varchar(20),exist varchar(20));

select * from signuptwo;

create table signupthree(formno varchar(20),accounType varchar(40),cardnumber varchar(25),pin varchar(10),facility varchar(100));
create table login(formno varchar(20),cardnumber varchar(25),pin varchar(10));
select * from signupthree;
select * from login;
select * from bank;

create table bank(pin varchar(10),date varchar(50),type varchar(20),amount varchar(20));
/*com.mysql.cj.jdbc.exceptions.MysqlDataTruncation: Data truncation: Data too long for column 'date' at row 1=>date varchar(20) change from 20->50*/